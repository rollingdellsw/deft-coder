#!/usr/bin/env node
// scripts/postinstall.js
// Comprehensive setup script for Deft with nvim plugin support

import {mkdir, copyFile, access, readdir, readFile, appendFile, rename, cp} from 'fs/promises';
import {join, dirname} from 'path';
import {fileURLToPath} from 'url';
import {homedir} from 'os';
import {execSync} from 'child_process';

const __dirname = dirname(fileURLToPath(import.meta.url));
const configDir = join(homedir(), '.config', 'deft');
const sessionsDir = join(configDir, 'sessions');

// Colors for terminal output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  red: '\x1b[31m',
  cyan: '\x1b[36m',
};

function log(emoji, message, color = colors.reset) {
  console.log(`${color}${emoji} ${message}${colors.reset}`);
}

async function fileExists(path) {
  try {
    await access(path);
    return true;
  } catch {
    return false;
  }
}

function commandExists(command) {
  try {
    execSync(`command -v ${command}`, {stdio: 'ignore'});
    return true;
  } catch {
    return false;
  }
}

function isDocker() {
  try {
    execSync('docker --version', {stdio: 'ignore'});
    return true;
  } catch {
    return false;
  }
}

async function setupConfigFiles() {
  log('🔧', 'Setting up Deft configuration files...', colors.blue);
  console.log();

  try {
    // Create directories
    log('📁', `Creating directory: ${configDir}`, colors.reset);
    await mkdir(configDir, {recursive: true});

    log('📁', `Creating directory: ${sessionsDir}`, colors.reset);
    await mkdir(sessionsDir, {recursive: true});

    // Find all config.*.json files in the configs directory
    const configsDir = join(__dirname, '..', 'configs');
    const configsEntries = await readdir(configsDir);
    const providerConfigs = configsEntries.filter(
        f => f.startsWith('config.') && f.endsWith('.json'));

    // Copy all provider config files (always overwrite to ensure latest)
    for (const configFile of providerConfigs) {
      const source = join(configsDir, configFile);
      const dest = join(configDir, configFile);
      await copyFile(source, dest);
      log('   ✅', `Copied ${configFile}`, colors.green);
    }

    // Define other config files to copy (with backup behavior)
    const configFiles = [
      {
        name: 'config.json',
        dest: join(configDir, 'config.json'),
        source: join(configsDir, 'config.glm.json'),
        description: 'Config file',
        postMessage: 'Remember to add your API key!',
      },
      {
        name: 'system_prompt.md',
        dest: join(configDir, 'system_prompt.md'),
        source: join(configsDir, 'system_prompt.example.md'),
        description: 'System prompt',
      },
      {
        name: 'guardrails.js',
        dest: join(configDir, 'guardrails.js'),
        source: join(configsDir, 'guardrails.js'),
        description: 'Guardrails file',
      },
      {
        name: 'reminders.json',
        dest: join(configDir, 'reminders.json'),
        source: join(configsDir, 'reminders.example.json'),
        description: 'Reminders file',
      },
    ];

    // Process each config file
    for (const file of configFiles) {
      const exists = await fileExists(file.dest);

      if (exists) {
        const backupPath = `${file.dest}.orig`;
        log('📦', `Backing up: ${file.dest} → ${backupPath}`, colors.yellow);
        await rename(file.dest, backupPath);
        await copyFile(file.source, file.dest);
        log('   ✅', `${file.description} updated (old config saved as .orig)`,
            colors.green);
      } else {
        log('📄', `Copying ${file.description}: ${file.dest}`, colors.reset);
        await copyFile(file.source, file.dest);
        log('   ✅', `${file.description} created`, colors.green);
        if (file.postMessage) {
          log('   ⚠️ ', file.postMessage, colors.yellow);
        }
      }
    }

    console.log();
    log('✅', 'Configuration files setup complete!', colors.green);
    log('💡',
        'If you had existing configs, they were backed up with .orig extension',
        colors.cyan);
    log('💡', 'You may want to merge your old settings from *.orig files',
        colors.cyan);

  } catch (error) {
    log('❌', `Error setting up config files: ${error.message}`, colors.red);
  }
}

async function setupNeovimPlugin() {
  console.log();
  log('🔌', 'Setting up Neovim plugin...', colors.blue);
  console.log();

  try {
    // Check if Neovim config directory exists
    const nvimConfigDir = join(homedir(), '.config', 'nvim');

    if (!(await fileExists(nvimConfigDir))) {
      log('⚠️ ', 'Neovim config directory not found (skipping plugin install)',
          colors.yellow);
      log('   ', `Expected: ${nvimConfigDir}`, colors.reset);
      return false;
    }

    // Create plugin directory
    const nvimPluginDir = join(nvimConfigDir, 'lua', 'deft');
    log('📁', `Creating plugin directory: ${nvimPluginDir}`, colors.reset);
    await mkdir(nvimPluginDir, {recursive: true});

    // Source plugin files
    const sourcePluginDir = join(__dirname, '..', 'nvim-plugin');

    if (!(await fileExists(sourcePluginDir))) {
      log('⚠️ ', 'nvim-plugin directory not found in package', colors.yellow);
      return false;
    }

    // Copy all .lua files
    const files = await readdir(sourcePluginDir);
    const luaFiles = files.filter(f => f.endsWith('.lua'));

    if (luaFiles.length === 0) {
      log('⚠️ ', 'No .lua files found in nvim-plugin directory', colors.yellow);
      return false;
    }

    log('📄', `Copying ${luaFiles.length} plugin file(s)...`, colors.reset);

    for (const file of luaFiles) {
      const sourcePath = join(sourcePluginDir, file);
      const destPath = join(nvimPluginDir, file);

      await copyFile(sourcePath, destPath);
      log('   ✅', `Copied ${file}`, colors.green);
    }

    console.log();
    log('✅', 'Neovim plugin installed successfully!', colors.green);

    // Auto-add to init.lua
    const initLuaPath = join(nvimConfigDir, 'init.lua');

    if (await fileExists(initLuaPath)) {
      const initContent = await readFile(initLuaPath, 'utf8');

      if (initContent.includes('require(\'deft\')')) {
        console.log();
        log('ℹ️ ', 'Already configured in init.lua', colors.cyan);
      } else {
        log('📝', 'Adding to init.lua...', colors.cyan);

        const setupLine = '\n-- Deft integration\nrequire(\'deft\').setup()\n';
        await appendFile(initLuaPath, setupLine);

        log('   ✅', 'Added to init.lua', colors.green);
      }
    } else {
      console.log();
      log('📝', 'Next step for Neovim integration:', colors.cyan);
      console.log(`   Create ${initLuaPath} and add:`);
      console.log();
      console.log(`   ${colors.cyan}require('deft').setup()${colors.reset}`);
      console.log();
    }

    return true;

  } catch (error) {
    log('❌', `Error installing Neovim plugin: ${error.message}`, colors.red);
    log('   ', 'You can install it manually later', colors.reset);
    return false;
  }
}

async function checkOptionalDependencies() {
  console.log();
  log('🔍', 'Checking optional dependencies...', colors.blue);
  console.log();

  const suggestions = [];

  // Check for ripgrep
  if (commandExists('rg')) {
    log('✅', 'ripgrep is installed', colors.green);
  } else {
    log('⚠️ ', 'ripgrep not found (optional for faster code search)',
        colors.yellow);
    suggestions.push({
      tool: 'ripgrep',
      purpose: 'Fast code search',
      install: getInstallCommand('ripgrep')
    });
  }

  // Check for Docker
  if (isDocker()) {
    log('✅', 'Docker is installed', colors.green);

    // Check if ts-sandbox image exists
    try {
      execSync('docker images -q ts-sandbox', {stdio: 'pipe'});
      const hasImage =
          execSync('docker images -q ts-sandbox', {encoding: 'utf8'}).trim();

      if (hasImage) {
        log('✅', 'ts-sandbox Docker image found', colors.green);
      } else {
        log('⚠️ ', 'ts-sandbox Docker image not built', colors.yellow);
        suggestions.push({
          tool: 'ts-sandbox',
          purpose: 'TypeScript sandbox environment',
          install: 'docker build -t ts-sandbox ./mcp-server/sandbox-ts'
        });
      }
    } catch {
      log('⚠️ ', 'ts-sandbox Docker image not built', colors.yellow);
      suggestions.push({
        tool: 'ts-sandbox',
        purpose: 'TypeScript sandbox environment',
        install: 'docker build -t ts-sandbox ./mcp-server/sandbox-ts'
      });
    }
  } else {
    log('⚠️ ', 'Docker not found (optional for TypeScript sandbox)',
        colors.yellow);
    suggestions.push({
      tool: 'Docker',
      purpose: 'TypeScript sandbox environment',
      install: 'Install from: https://docs.docker.com/get-docker/'
    });
  }

  return suggestions;
}

async function setupSkills() {
  console.log();
  log('🧠', 'Setting up default skills...', colors.blue);
  console.log();

  const skillsDestDir = join(configDir, 'skills');

  // Source path in the installed package
  const skillsSourceDir = join(__dirname, '..', 'skills');

  if (await fileExists(skillsSourceDir)) {
    try {
      await mkdir(skillsDestDir, {recursive: true});
      const entries = await readdir(skillsSourceDir, {withFileTypes: true});

      for (const entry of entries) {
        if (entry.isDirectory()) {
          const src = join(skillsSourceDir, entry.name);
          const dest = join(skillsDestDir, entry.name);
          // Recursive copy (overwrites to ensure latest skill definition)
          await cp(src, dest, {recursive: true, force: true});
          log('   ✅', `Installed skill: ${entry.name}`, colors.green);
        }
      }
    } catch (error) {
      log('❌', `Error setting up skills: ${error.message}`, colors.red);
    }
  } else {
    // Silently skip if no skills folder found (e.g. dev environment)
  }
}

function getInstallCommand(tool) {
  const platform = process.platform;

  if (tool === 'ripgrep') {
    if (platform === 'linux') {
      // Detect Linux distro
      try {
        const osRelease = execSync('cat /etc/os-release', {encoding: 'utf8'});
        if (osRelease.includes('Ubuntu') || osRelease.includes('Debian')) {
          return 'sudo apt install ripgrep';
        } else if (
            osRelease.includes('Fedora') || osRelease.includes('CentOS') ||
            osRelease.includes('Red Hat')) {
          return 'sudo dnf install ripgrep';
        } else if (osRelease.includes('Arch')) {
          return 'sudo pacman -S ripgrep';
        }
      } catch {
        return 'sudo apt install ripgrep  # or your package manager';
      }
    } else if (platform === 'darwin') {
      return 'brew install ripgrep';
    } else if (platform === 'win32') {
      return 'choco install ripgrep  # or: scoop install ripgrep';
    }
  }

  return 'See installation instructions';
}

async function findMcpServerDir() {
  // 1. Try local package (distribution mode)
  let path = join(__dirname, '..', 'mcp-server');
  if (await fileExists(path)) return path;

  // 2. Try monorepo sibling (development mode)
  path = join(__dirname, '..', '..', 'llm-node', 'mcp-server');
  if (await fileExists(path)) return path;

  return null;
}

async function promptUserForSetup(suggestions) {
  if (suggestions.length === 0) {
    console.log();
    log('🎉', 'All optional dependencies are installed!', colors.green);
    return;
  }

  console.log();
  log('📋', 'Optional setup steps:', colors.blue);
  console.log();

  suggestions.forEach((suggestion, index) => {
    console.log(`${colors.yellow}${index + 1}. ${suggestion.tool}${
        colors.reset} - ${suggestion.purpose}`);
    console.log(`   ${colors.reset}${suggestion.install}${colors.reset}`);
    console.log();
  });
}

async function buildDockerImageIfPossible() {
  if (!isDocker()) {
    return false;
  }

  const mcpDir = await findMcpServerDir();
  if (!mcpDir) return false;

  const sandboxDir = join(mcpDir, 'sandbox-ts');
  const dockerfile = join(sandboxDir, 'Dockerfile');

  if (!(await fileExists(dockerfile))) return false;

  try {
    log('🐳', 'Attempting to build ts-sandbox Docker image...', colors.blue);

    // Build the image (but don't fail if it doesn't work)
    execSync(
        `docker build -t ts-sandbox ${sandboxDir}`,
        {stdio: 'inherit', cwd: join(__dirname, '..')});

    log('✅', 'ts-sandbox Docker image built successfully!', colors.green);
    return true;
  } catch (error) {
    log('⚠️ ', 'Could not build Docker image automatically', colors.yellow);
    log('   ', 'You can build it manually later with:', colors.reset);
    log('   ', 'docker build -t ts-sandbox ./mcp-server/sandbox-ts',
        colors.reset);
    return false;
  }
}

async function main() {
  console.log();
  log('🚀', 'Deft Post-Install Setup', colors.blue);
  console.log('━'.repeat(50));
  console.log();

  // Always set up config files
  await setupConfigFiles();

  // Set up Neovim plugin (if Neovim is installed)
  await setupNeovimPlugin();

  // Set up Skills
  await setupSkills();

  // Check optional dependencies
  const suggestions = await checkOptionalDependencies();

  // Try to build Docker image if possible (global install only)
  if (process.env.npm_config_global === 'true') {
    await buildDockerImageIfPossible();
  }

  // Show optional setup steps
  await promptUserForSetup(suggestions);

  // Final instructions
  console.log();
  console.log('━'.repeat(50));
  log('📍', `Config location: ${configDir}`, colors.reset);
  console.log();
  log('📝', 'Next steps:', colors.blue);
  console.log('   1. Edit ~/.deft/config.json and add your API key');
  console.log('   2. Run: deft');
  console.log();
}

// Run the setup
main().catch(error => {
  console.error('\n❌ Setup error:', error.message);
  // Don't fail installation
  process.exit(0);
});
